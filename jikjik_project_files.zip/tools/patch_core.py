#!/usr/bin/env python3
"""Wires the JikJik backend into the Telegram client. Fails loudly if an anchor is missing."""
import os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = 'TMessagesProj/src/main/java/org/telegram'

def rd(p):
    with open(p, encoding='utf-8', errors='surrogateescape') as f: return f.read()
def wr(p, s):
    with open(p, 'w', encoding='utf-8', errors='surrogateescape', newline='') as f: f.write(s)
def find(name):
    for root, _, files in os.walk(SRC):
        if name in files: return os.path.join(root, name)
    sys.exit('PATCH FAILED: %s not found' % name)

# 1) copy new sources
for root, _, files in os.walk(os.path.join(HERE, 'jik_src')):
    for f in files:
        rel = os.path.relpath(os.path.join(root, f), os.path.join(HERE, 'jik_src'))
        dst = os.path.join('TMessagesProj/src/main/java', rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy(os.path.join(root, f), dst)
        print('added', dst)

# Keep TL_update aligned with the generated package used by this Telegram branch.
sync_path = os.path.join(SRC, 'messenger', 'jik', 'JikSync.java')
sync_source = rd(sync_path)
wrong_import = 'import org.telegram.tgnet.TL_update;'
right_import = 'import org.telegram.tgnet.tl.TL_update;'
if wrong_import in sync_source:
    sync_source = sync_source.replace(wrong_import, right_import)
if right_import not in sync_source:
    sys.exit('PATCH FAILED: JikSync.java has no supported TL_update import')
wr(sync_path, sync_source)
print('fixed JikSync TL_update package import')

# 2) LaunchActivity: always show the JikJik auth screen when not logged in
p = find('LaunchActivity.java'); s = rd(p)
pat = re.compile(r'private BaseFragment getClientNotActivatedFragment\(\) \{.*?\n    \}\n', re.S)
assert pat.search(s), 'PATCH FAILED: getClientNotActivatedFragment'
s = pat.sub('private BaseFragment getClientNotActivatedFragment() {\n        return new JikAuthActivity();\n    }\n', s, count=1)
wr(p, s); print('patched LaunchActivity')

# 3) ConnectionsManager: answer every request from the JikJik API, never send to Telegram
p = find('ConnectionsManager.java'); s = rd(p)
anchor = '''            FileLog.d("send request " + object + " with token = " + requestToken);
        }
'''
assert s.count(anchor) == 1, 'PATCH FAILED: sendRequestInternal anchor (%d)' % s.count(anchor)
hook = anchor + '''        if (org.telegram.messenger.jik.JikBridge.handle(currentAccount, object, (jikResponse, jikError) -> {
            if (onComplete != null) {
                onComplete.run(jikResponse, jikError);
            } else if (onCompleteTimestamp != null) {
                onCompleteTimestamp.run(jikResponse, jikError, 0);
            } else if (jikResponse instanceof TLRPC.Updates) {
                AccountInstance.getInstance(currentAccount).getMessagesController().processUpdates((TLRPC.Updates) jikResponse, false);
            }
        })) {
            return;
        }
'''
s = s.replace(anchor, hook, 1)
a2 = 'public static void onLogout(final int currentAccount) {\n'
assert s.count(a2) == 1, 'PATCH FAILED: onLogout'
s = s.replace(a2, a2 + '        if (org.telegram.messenger.jik.JikApi.hasSession()) {\n            return; // the native layer must never log us out\n        }\n', 1)
wr(p, s); print('patched ConnectionsManager')
print('patch_core done')
