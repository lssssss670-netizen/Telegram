package org.telegram.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;
import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.MessagesController;
import org.telegram.messenger.MessagesStorage;
import org.telegram.messenger.NotificationCenter;
import org.telegram.messenger.UserConfig;
import org.telegram.messenger.jik.JikApi;
import org.telegram.messenger.jik.JikBridge;
import org.telegram.messenger.jik.JikSync;
import org.telegram.tgnet.TLRPC;
import org.telegram.ui.ActionBar.BaseFragment;

import java.util.ArrayList;

/** JikJik sign-in / sign-up: username + password (+ first and last name). No phone number, no Telegram servers. */
public class JikAuthActivity extends BaseFragment {

    private static final int GREEN = 0xFF1DA851;

    private boolean registerMode = false;
    private EditText usernameField, passwordField, firstField, lastField;
    private LinearLayout nameRow;
    private TextView titleView, submitView, toggleView, errorView;
    private boolean busy = false;

    @Override
    public View createView(Context context) {
        actionBar.setAddToContainer(false);

        ScrollView scroll = new ScrollView(context);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.WHITE);

        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = AndroidUtilities.dp(28);
        root.setPadding(pad, AndroidUtilities.dp(72), pad, AndroidUtilities.dp(32));
        scroll.addView(root, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        titleView = new TextView(context);
        titleView.setTextSize(26);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setTextColor(GREEN);
        titleView.setGravity(Gravity.CENTER);
        root.addView(titleView, lp(-1, -2, 0, 0, 0, 6));

        TextView sub = new TextView(context);
        sub.setTextSize(14);
        sub.setTextColor(0xFF777777);
        sub.setGravity(Gravity.CENTER);
        sub.setText("جیک جیک");
        root.addView(sub, lp(-1, -2, 0, 0, 0, 28));

        nameRow = new LinearLayout(context);
        nameRow.setOrientation(LinearLayout.VERTICAL);
        firstField = field(context, "نام", false);
        lastField = field(context, "نام خانوادگی", false);
        nameRow.addView(firstField, lp(-1, 52, 0, 0, 0, 12));
        nameRow.addView(lastField, lp(-1, 52, 0, 0, 0, 12));
        root.addView(nameRow, lp(-1, -2, 0, 0, 0, 0));

        usernameField = field(context, "نام کاربری (انگلیسی)", false);
        usernameField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        passwordField = field(context, "رمز عبور", true);
        root.addView(usernameField, lp(-1, 52, 0, 0, 0, 12));
        root.addView(passwordField, lp(-1, 52, 0, 0, 0, 12));

        errorView = new TextView(context);
        errorView.setTextColor(0xFFD32F2F);
        errorView.setTextSize(13);
        errorView.setGravity(Gravity.CENTER);
        root.addView(errorView, lp(-1, -2, 0, 4, 0, 8));

        submitView = new TextView(context);
        submitView.setTextColor(Color.WHITE);
        submitView.setTextSize(16);
        submitView.setTypeface(Typeface.DEFAULT_BOLD);
        submitView.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(GREEN);
        bg.setCornerRadius(AndroidUtilities.dp(12));
        submitView.setBackground(bg);
        submitView.setOnClickListener(v -> submit());
        root.addView(submitView, lp(-1, 52, 0, 8, 0, 0));

        toggleView = new TextView(context);
        toggleView.setTextColor(GREEN);
        toggleView.setTextSize(14);
        toggleView.setGravity(Gravity.CENTER);
        toggleView.setPadding(0, AndroidUtilities.dp(16), 0, AndroidUtilities.dp(16));
        toggleView.setOnClickListener(v -> {
            registerMode = !registerMode;
            errorView.setText("");
            refresh();
        });
        root.addView(toggleView, lp(-1, -2, 0, 12, 0, 0));

        refresh();
        fragmentView = scroll;
        return fragmentView;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        int ww = w > 0 ? AndroidUtilities.dp(w) : w;
        int hh = h > 0 ? AndroidUtilities.dp(h) : h;
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ww, hh);
        p.setMargins(AndroidUtilities.dp(l), AndroidUtilities.dp(t), AndroidUtilities.dp(r), AndroidUtilities.dp(b));
        return p;
    }

    private EditText field(Context context, String hint, boolean password) {
        EditText e = new EditText(context);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setTextColor(0xFF222222);
        e.setHintTextColor(0xFF9E9E9E);
        e.setPadding(AndroidUtilities.dp(14), 0, AndroidUtilities.dp(14), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFF4F6F5);
        bg.setCornerRadius(AndroidUtilities.dp(12));
        bg.setStroke(AndroidUtilities.dp(1), 0xFFDDE3E0);
        e.setBackground(bg);
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    private void refresh() {
        titleView.setText(registerMode ? "ساخت حساب" : "ورود");
        submitView.setText(registerMode ? "ثبت‌نام" : "ورود");
        toggleView.setText(registerMode ? "حساب داری؟ وارد شو" : "حساب نداری؟ ثبت‌نام کن");
        nameRow.setVisibility(registerMode ? View.VISIBLE : View.GONE);
    }

    private void setBusy(boolean b) {
        busy = b;
        submitView.setAlpha(b ? 0.5f : 1f);
        submitView.setText(b ? "صبر کن..." : (registerMode ? "ثبت‌نام" : "ورود"));
    }

    private void submit() {
        if (busy) return;
        final String username = usernameField.getText().toString().trim();
        final String password = passwordField.getText().toString();
        final String first = firstField.getText().toString().trim();
        final String last = lastField.getText().toString().trim();
        if (username.isEmpty() || password.isEmpty()) {
            errorView.setText("نام کاربری و رمز رو بزن");
            return;
        }
        if (registerMode && (first.isEmpty() || last.isEmpty())) {
            errorView.setText("نام و نام خانوادگی لازمه");
            return;
        }
        errorView.setText("");
        setBusy(true);
        final boolean reg = registerMode;
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("username", username);
                body.put("password", password);
                body.put("device", "Android");
                if (reg) {
                    body.put("first_name", first);
                    body.put("last_name", last);
                }
                JSONObject res = JikApi.post(reg ? "register.php" : "login.php", body);
                final String token = res.getString("token");
                final JSONObject user = res.getJSONObject("user");
                AndroidUtilities.runOnUIThread(() -> onSuccess(token, user));
            } catch (final JikApi.JikException e) {
                AndroidUtilities.runOnUIThread(() -> {
                    setBusy(false);
                    errorView.setText(e.getMessage());
                });
            } catch (Throwable t) {
                AndroidUtilities.runOnUIThread(() -> {
                    setBusy(false);
                    errorView.setText("اتصال به سرور برقرار نشد. اینترنت رو چک کن");
                });
            }
        }).start();
    }

    private void onSuccess(String token, JSONObject userJson) {
        try {
            TLRPC.TL_user user = JikBridge.buildUser(userJson, userJson.getLong("id"), true);
            JikApi.saveSession(token, user.id);
            JikSync.stop();

            MessagesController.getInstance(currentAccount).cleanup();
            UserConfig.getInstance(currentAccount).clearConfig();
            MessagesController.getInstance(currentAccount).cleanup();
            UserConfig.getInstance(currentAccount).setCurrentUser(user);
            UserConfig.getInstance(currentAccount).saveConfig(true);
            MessagesStorage.getInstance(currentAccount).cleanup(true);
            ArrayList<TLRPC.User> users = new ArrayList<>();
            users.add(user);
            MessagesStorage.getInstance(currentAccount).putUsersAndChats(users, null, true, true);
            MessagesController.getInstance(currentAccount).putUser(user, false);

            Bundle args = new Bundle();
            args.putBoolean("afterSignup", false);
            MainTabsActivity main = new MainTabsActivity();
            main.prepareDialogsActivity(args);
            presentFragment(main, true);
            NotificationCenter.getInstance(currentAccount).postNotificationName(NotificationCenter.mainUserInfoChanged);
        } catch (Throwable t) {
            setBusy(false);
            errorView.setText("خطا در ساخت نشست");
        }
    }
}
