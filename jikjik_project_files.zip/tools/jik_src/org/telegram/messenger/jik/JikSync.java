package org.telegram.messenger.jik;

import org.json.JSONArray;
import org.json.JSONObject;
import org.telegram.messenger.MessagesController;
import org.telegram.messenger.Utilities;
import org.telegram.tgnet.tl.TL_update;
import org.telegram.tgnet.TLObject;
import org.telegram.tgnet.TLRPC;

/** Long-poll loop: turns new messages from the PHP API into Telegram-style updates. */
public class JikSync {

    private static volatile boolean running = false;

    public static void ensureStarted(final int account) {
        if (running || !JikApi.hasSession()) return;
        synchronized (JikSync.class) {
            if (running) return;
            running = true;
        }
        Thread t = new Thread(() -> loop(account), "jik-sync");
        t.setDaemon(true);
        t.start();
    }

    public static void stop() {
        running = false;
    }

    private static void loop(final int account) {
        int failures = 0;
        while (running && JikApi.hasSession()) {
            try {
                long me = JikApi.getUserId();
                long cursor = JikApi.getCursor();
                if (cursor < 0) {
                    JSONObject first = JikApi.get("chats.php", null, 20);
                    cursor = first.optLong("cursor", 0);
                    long maxId = 0;
                    JSONArray chats = first.optJSONArray("chats");
                    for (int i = 0; chats != null && i < chats.length(); i++) {
                        JSONObject lm = chats.getJSONObject(i).optJSONObject("last_message");
                        if (lm != null) maxId = Math.max(maxId, lm.optLong("id", 0));
                    }
                    JikApi.setCursor(cursor);
                    JikApi.setLastMsgId(maxId);
                }
                JSONObject p = new JSONObject();
                p.put("after", cursor);
                p.put("timeout", 20);
                JSONObject j = JikApi.get("poll.php", p, 40);
                long newCursor = j.optLong("cursor", cursor);
                deliver(account, me, j);
                JikApi.setCursor(newCursor);
                failures = 0;
            } catch (Throwable t) {
                failures++;
                try {
                    Thread.sleep(Math.min(30000, 2000L * failures));
                } catch (InterruptedException ignore) {
                }
            }
        }
        running = false;
    }

    private static void deliver(int account, long me, JSONObject j) throws Exception {
        JSONArray msgs = j.optJSONArray("messages");
        if (msgs == null || msgs.length() == 0) return;
        long lastId = JikApi.getLastMsgId();
        long newLast = lastId;
        final TLRPC.TL_updates updates = new TLRPC.TL_updates();
        updates.date = (int) (System.currentTimeMillis() / 1000);
        updates.seq = 0;
        for (int i = 0; i < msgs.length(); i++) {
            JSONObject m = msgs.getJSONObject(i);
            long id = m.optLong("id", 0);
            if (id <= lastId) continue;                       // edit/delete of an old message: v2
            newLast = Math.max(newLast, id);
            if (m.optBoolean("deleted")) continue;
            if (m.optLong("sender_id") == me) continue;       // our own messages are already local
            if (!"private".equals(m.optString("chat_type", "private"))) continue;
            long peer = m.optLong("peer_id", 0);
            if (peer == 0) continue;
            TL_update.TL_updateNewMessage u = new TL_update.TL_updateNewMessage();
            u.message = JikBridge.buildMessage(m, me, peer, 0, Integer.MAX_VALUE);
            u.pts = JikApi.nextPts();
            u.pts_count = 1;
            updates.updates.add(u);
        }
        JikApi.setLastMsgId(newLast);
        if (updates.updates.isEmpty()) return;
        JSONArray us = j.optJSONArray("users");
        for (int i = 0; us != null && i < us.length(); i++) {
            TLRPC.TL_user user = JikBridge.buildUser(us.getJSONObject(i), me, false);
            updates.users.add(user);
        }
        Utilities.stageQueue.postRunnable(() -> MessagesController.getInstance(account).processUpdates(updates, false));
    }
}
