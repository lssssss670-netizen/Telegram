package org.telegram.messenger.jik;

import org.json.JSONArray;
import org.json.JSONObject;
import org.telegram.messenger.UserConfig;
import org.telegram.messenger.Utilities;
import org.telegram.tgnet.RequestDelegate;
import org.telegram.tgnet.TLObject;
import org.telegram.tgnet.TLRPC;
import org.telegram.tgnet.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Replaces the Telegram network layer: every TL request made by the app is answered
 * from the JikJik PHP API (https://alimsv.ir/api/). Nothing is sent to Telegram servers.
 */
public class JikBridge {

    public interface Callback {
        void done(TLObject response, TLRPC.TL_error error);
    }

    private static final ExecutorService EXEC = Executors.newFixedThreadPool(4);
    private static final HashMap<Long, Object[]> userCache = new HashMap<>(); // id -> {TL_user, timeMillis}

    /** Always returns true: the request is consumed here, never sent to the native MTProto layer. */
    public static boolean handle(final int account, final TLObject req, final Callback cb) {
        EXEC.execute(() -> {
            TLObject resp = null;
            TLRPC.TL_error err = null;
            try {
                JikSync.ensureStarted(account);
                resp = process(account, req);
                if (resp == null) err = error(400, "JIK_UNSUPPORTED");
            } catch (JikApi.JikException e) {
                err = error(400, e.code + "");
            } catch (Throwable t) {
                err = error(500, "JIK_NETWORK");
            }
            final TLObject fr = resp;
            final TLRPC.TL_error fe = err;
            Utilities.stageQueue.postRunnable(() -> cb.done(fr, fe));
        });
        return true;
    }

    private static TLRPC.TL_error error(int code, String text) {
        TLRPC.TL_error e = new TLRPC.TL_error();
        e.code = code;
        e.text = text;
        return e;
    }

    /* ------------------------------------------------------------------ */
    /*  request routing                                                    */
    /* ------------------------------------------------------------------ */

    private static TLObject process(int account, TLObject req) throws Exception {
        if (!JikApi.hasSession()) {
            return null;
        }
        if (!UserConfig.getInstance(account).isClientActivated()) {
            // user logged out inside the app: drop our session too
            JikApi.clearSession();
            JikSync.stop();
            return null;
        }
        long me = JikApi.getUserId();

        if (req instanceof TLRPC.TL_messages_getDialogs) {
            return getDialogs((TLRPC.TL_messages_getDialogs) req, me);
        }
        if (req instanceof TLRPC.TL_messages_getPeerDialogs) {
            TLRPC.TL_messages_dialogs all = getDialogs(null, me);
            TLRPC.TL_messages_peerDialogs res = new TLRPC.TL_messages_peerDialogs();
            res.dialogs = all.dialogs;
            res.messages = all.messages;
            res.chats = all.chats;
            res.users = all.users;
            res.state = state();
            return res;
        }
        if (req instanceof TLRPC.TL_messages_getHistory) {
            return getHistory((TLRPC.TL_messages_getHistory) req, me);
        }
        if (req instanceof TLRPC.TL_messages_sendMessage) {
            return sendMessage((TLRPC.TL_messages_sendMessage) req, me);
        }
        if (req instanceof TLRPC.TL_messages_readHistory) {
            TLRPC.TL_messages_readHistory r = (TLRPC.TL_messages_readHistory) req;
            long peer = peerUserId(r.peer, me);
            if (peer != 0) {
                JSONObject b = new JSONObject();
                b.put("user_id", peer);
                b.put("up_to_id", r.max_id);
                JikApi.post("mark_read.php", b);
            }
            TLRPC.TL_messages_affectedMessages res = new TLRPC.TL_messages_affectedMessages();
            res.pts = JikApi.getPts();
            res.pts_count = 0;
            return res;
        }
        if (req instanceof TLRPC.TL_messages_deleteMessages) {
            TLRPC.TL_messages_deleteMessages r = (TLRPC.TL_messages_deleteMessages) req;
            for (int i = 0; i < r.id.size(); i++) {
                JSONObject b = new JSONObject();
                b.put("message_id", r.id.get(i));
                try {
                    JikApi.post("delete_message.php", b);
                } catch (JikApi.JikException ignore) {
                }
            }
            TLRPC.TL_messages_affectedMessages res = new TLRPC.TL_messages_affectedMessages();
            res.pts = JikApi.nextPts();
            res.pts_count = 1;
            return res;
        }
        if (req instanceof TLRPC.TL_contacts_search) {
            return contactsSearch((TLRPC.TL_contacts_search) req, me);
        }
        if (req instanceof TLRPC.TL_contacts_getContacts) {
            return getContacts(me);
        }
        if (req instanceof TLRPC.TL_users_getUsers) {
            TLRPC.TL_users_getUsers r = (TLRPC.TL_users_getUsers) req;
            Vector v = new Vector();
            for (int i = 0; i < r.id.size(); i++) {
                TLRPC.InputUser iu = r.id.get(i);
                long id = 0;
                if (iu instanceof TLRPC.TL_inputUserSelf) {
                    id = me;
                } else if (iu instanceof TLRPC.TL_inputUser) {
                    id = ((TLRPC.TL_inputUser) iu).user_id;
                }
                TLRPC.User u = id != 0 ? fetchUser(id, me) : null;
                if (u != null) v.objects.add(u);
            }
            return v;
        }
        if (req instanceof TLRPC.TL_updates_getState) {
            return state();
        }
        if (req instanceof TLRPC.TL_updates_getDifference) {
            TLRPC.TL_updates_difference d = new TLRPC.TL_updates_difference();
            d.state = state();
            return d;
        }
        return null;
    }

    /* ------------------------------------------------------------------ */
    /*  handlers                                                           */
    /* ------------------------------------------------------------------ */

    public static TLRPC.TL_updates_state state() {
        TLRPC.TL_updates_state s = new TLRPC.TL_updates_state();
        s.pts = JikApi.getPts();
        s.qts = 0;
        s.date = (int) (System.currentTimeMillis() / 1000);
        s.seq = 0;
        s.unread_count = 0;
        return s;
    }

    private static TLRPC.TL_messages_dialogs getDialogs(TLRPC.TL_messages_getDialogs req, long me) throws Exception {
        TLRPC.TL_messages_dialogs res = new TLRPC.TL_messages_dialogs();
        // folder 1 (archive) and paging requests: nothing more to give
        if (req != null && (req.folder_id != 0 || req.offset_date != 0 || req.offset_id != 0)) {
            return res;
        }
        JSONObject j = JikApi.get("chats.php", null, 20);
        JikApi.setCursorIfUnset(j.optLong("cursor", 0));
        LinkedHashMap<Long, TLRPC.User> users = new LinkedHashMap<>();
        users.put(me, fetchUser(me, me));
        JSONArray chats = j.getJSONArray("chats");
        for (int i = 0; i < chats.length(); i++) {
            JSONObject c = chats.getJSONObject(i);
            if (!"private".equals(c.optString("type"))) continue; // groups: later
            JSONObject peer = c.optJSONObject("peer");
            if (peer == null) continue;
            long peerId = peer.getLong("id");
            if (!users.containsKey(peerId)) users.put(peerId, buildUser(peer, me, peerId == me));
            JSONObject last = c.optJSONObject("last_message");
            if (last == null || last.optBoolean("deleted")) continue;
            int inboxMax = c.optInt("last_read_id", 0);
            int outboxMax = c.optInt("peer_last_read_id", 0);
            TLRPC.TL_message msg = buildMessage(last, me, peerId, inboxMax, outboxMax);

            TLRPC.TL_dialog d = new TLRPC.TL_dialog();
            TLRPC.TL_peerUser p = new TLRPC.TL_peerUser();
            p.user_id = peerId;
            d.peer = p;
            d.id = peerId;
            d.top_message = msg.id;
            d.last_message_date = msg.date;
            d.read_inbox_max_id = inboxMax;
            d.read_outbox_max_id = outboxMax;
            d.unread_count = c.optInt("unread", 0);
            d.notify_settings = new TLRPC.TL_peerNotifySettings();
            res.dialogs.add(d);
            res.messages.add(msg);
        }
        for (TLRPC.User u : users.values()) {
            if (u != null) res.users.add(u);
        }
        return res;
    }

    private static TLRPC.TL_messages_messages getHistory(TLRPC.TL_messages_getHistory req, long me) throws Exception {
        TLRPC.TL_messages_messages res = new TLRPC.TL_messages_messages();
        long peer = peerUserId(req.peer, me);
        if (peer == 0) return res;
        int limit = Math.max(1, Math.min(100, req.limit));

        ArrayList<JSONObject> list = new ArrayList<>(); // collected ascending
        if (req.min_id > 0) {
            list.addAll(history(peer, "after_id", req.min_id, limit));
        } else if (req.offset_id > 0 && req.add_offset < 0) {
            int newer = Math.min(limit, -req.add_offset);
            int older = Math.max(0, limit - newer);
            if (older > 0) list.addAll(history(peer, "before_id", req.offset_id, older));
            list.addAll(history(peer, "after_id", req.offset_id - 1, newer));
        } else if (req.offset_id > 0) {
            list.addAll(history(peer, "before_id", req.offset_id, limit));
        } else {
            list.addAll(history(peer, null, 0, limit));
        }

        JSONObject chats = JikApi.get("chats.php", null, 20);
        int inboxMax = 0, outboxMax = 0;
        JSONArray ca = chats.optJSONArray("chats");
        for (int i = 0; ca != null && i < ca.length(); i++) {
            JSONObject c = ca.getJSONObject(i);
            JSONObject pe = c.optJSONObject("peer");
            if ("private".equals(c.optString("type")) && pe != null && pe.optLong("id") == peer) {
                inboxMax = c.optInt("last_read_id", 0);
                outboxMax = c.optInt("peer_last_read_id", 0);
            }
        }
        // newest first, like Telegram
        for (int i = list.size() - 1; i >= 0; i--) {
            JSONObject m = list.get(i);
            if (m.optBoolean("deleted")) continue;
            res.messages.add(buildMessage(m, me, peer, inboxMax, outboxMax));
        }
        res.users.add(fetchUser(me, me));
        if (peer != me) {
            TLRPC.User pu = fetchUser(peer, me);
            if (pu != null) res.users.add(pu);
        }
        return res;
    }

    private static ArrayList<JSONObject> history(long peer, String key, int value, int limit) throws Exception {
        JSONObject p = new JSONObject();
        p.put("user_id", peer);
        p.put("limit", limit);
        if (key != null) p.put(key, value);
        JSONObject j = JikApi.get("messages.php", p, 20);
        JSONArray a = j.getJSONArray("messages");
        ArrayList<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) out.add(a.getJSONObject(i));
        return out;
    }

    private static TLObject sendMessage(TLRPC.TL_messages_sendMessage req, long me) throws Exception {
        long peer = peerUserId(req.peer, me);
        if (peer == 0 || req.message == null) return null;
        JSONObject b = new JSONObject();
        b.put("user_id", peer);
        b.put("text", req.message);
        JSONObject j = JikApi.post("send_message.php", b);
        JSONObject m = j.getJSONObject("message");
        TLRPC.TL_updateShortSentMessage u = new TLRPC.TL_updateShortSentMessage();
        u.flags = TLObject.FLAG_1;
        u.out = true;
        u.id = m.getInt("id");
        u.date = m.getInt("date");
        u.pts = JikApi.nextPts();
        u.pts_count = 1;
        return u;
    }

    private static TLObject contactsSearch(TLRPC.TL_contacts_search req, long me) throws Exception {
        TLRPC.TL_contacts_found res = new TLRPC.TL_contacts_found();
        String q = req.q == null ? "" : req.q.trim();
        if (q.startsWith("@")) q = q.substring(1);
        if (q.length() < 2) return res;
        JSONObject p = new JSONObject();
        p.put("q", q);
        JSONObject j = JikApi.get("search_users.php", p, 20);
        JSONArray a = j.getJSONArray("users");
        for (int i = 0; i < a.length(); i++) {
            JSONObject u = a.getJSONObject(i);
            TLRPC.TL_user user = buildUser(u, me, false);
            cacheUser(user);
            res.users.add(user);
            TLRPC.TL_peerUser pu = new TLRPC.TL_peerUser();
            pu.user_id = user.id;
            res.results.add(pu);
        }
        return res;
    }

    private static TLObject getContacts(long me) throws Exception {
        TLRPC.TL_contacts_contacts res = new TLRPC.TL_contacts_contacts();
        JSONObject j = JikApi.get("chats.php", null, 20);
        JSONArray chats = j.getJSONArray("chats");
        for (int i = 0; i < chats.length(); i++) {
            JSONObject c = chats.getJSONObject(i);
            JSONObject peer = c.optJSONObject("peer");
            if (!"private".equals(c.optString("type")) || peer == null || peer.optLong("id") == me) continue;
            TLRPC.TL_user u = buildUser(peer, me, false);
            u.contact = true;
            u.mutual_contact = true;
            u.flags |= TLObject.FLAG_11 | TLObject.FLAG_12;
            res.users.add(u);
            TLRPC.TL_contact ct = new TLRPC.TL_contact();
            ct.user_id = u.id;
            ct.mutual = true;
            res.contacts.add(ct);
        }
        res.saved_count = 0;
        return res;
    }

    /* ------------------------------------------------------------------ */
    /*  helpers: JSON -> TL                                                */
    /* ------------------------------------------------------------------ */

    private static long peerUserId(TLRPC.InputPeer peer, long me) {
        if (peer instanceof TLRPC.TL_inputPeerSelf) return me;
        if (peer instanceof TLRPC.TL_inputPeerUser) return ((TLRPC.TL_inputPeerUser) peer).user_id;
        return 0;
    }

    private static synchronized void cacheUser(TLRPC.User u) {
        userCache.put(u.id, new Object[]{u, System.currentTimeMillis()});
    }

    public static TLRPC.User fetchUser(long id, long me) throws Exception {
        synchronized (JikBridge.class) {
            Object[] e = userCache.get(id);
            if (e != null && System.currentTimeMillis() - (Long) e[1] < 60000) return (TLRPC.User) e[0];
        }
        JSONObject p = new JSONObject();
        p.put("id", id);
        JSONObject j = JikApi.get("get_user.php", p, 20);
        TLRPC.TL_user u = buildUser(j.getJSONObject("user"), me, id == me);
        cacheUser(u);
        return u;
    }

    public static TLRPC.TL_user buildUser(JSONObject j, long me, boolean self) throws Exception {
        TLRPC.TL_user u = new TLRPC.TL_user();
        u.id = j.getLong("id");
        u.first_name = j.optString("first_name", "");
        u.last_name = j.optString("last_name", "");
        u.username = j.optString("username", "");
        u.access_hash = u.id;
        u.self = self;
        u.flags = TLObject.FLAG_0 | TLObject.FLAG_1 | TLObject.FLAG_2 | TLObject.FLAG_3 | TLObject.FLAG_5 | TLObject.FLAG_6;
        if (self) u.flags |= TLObject.FLAG_10;
        u.photo = new TLRPC.TL_userProfilePhotoEmpty();
        long seen = j.optLong("last_seen", 0);
        if (j.optBoolean("online", false)) {
            TLRPC.TL_userStatusOnline s = new TLRPC.TL_userStatusOnline();
            s.expires = (int) (System.currentTimeMillis() / 1000) + 60;
            u.status = s;
        } else {
            TLRPC.TL_userStatusOffline s = new TLRPC.TL_userStatusOffline();
            s.expires = (int) seen;
            u.status = s;
        }
        return u;
    }

    public static TLRPC.TL_message buildMessage(JSONObject m, long me, long peerUserId, int inboxMax, int outboxMax) throws Exception {
        TLRPC.TL_message msg = new TLRPC.TL_message();
        long sender = m.getLong("sender_id");
        msg.id = m.getInt("id");
        msg.out = sender == me;
        TLRPC.TL_peerUser from = new TLRPC.TL_peerUser();
        from.user_id = sender;
        msg.from_id = from;
        TLRPC.TL_peerUser to = new TLRPC.TL_peerUser();
        to.user_id = msg.out ? peerUserId : me;
        msg.peer_id = to;
        msg.date = m.getInt("date");
        msg.message = m.optString("text", "");
        msg.media = new TLRPC.TL_messageMediaEmpty();
        msg.flags = TLObject.FLAG_8 | TLObject.FLAG_9;
        if (msg.out) msg.flags |= TLObject.FLAG_1;
        msg.dialog_id = peerUserId;
        msg.unread = msg.out ? msg.id > outboxMax : msg.id > inboxMax;
        return msg;
    }
}
