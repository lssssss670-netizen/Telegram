package org.telegram.messenger.jik;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;
import org.telegram.messenger.ApplicationLoader;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;

/** HTTP client for https://alimsv.ir/api/ + session storage. */
public class JikApi {

    public static final String BASE_URL = "https://alimsv.ir/api/";

    public static class JikException extends Exception {
        public final int http;
        public final String code;
        public JikException(int http, String code, String message) {
            super(message);
            this.http = http;
            this.code = code;
        }
    }

    private static SharedPreferences prefs() {
        return ApplicationLoader.applicationContext.getSharedPreferences("jik_session", Context.MODE_PRIVATE);
    }

    public static synchronized String getToken() {
        return prefs().getString("token", "");
    }

    public static synchronized long getUserId() {
        return prefs().getLong("user_id", 0);
    }

    public static boolean hasSession() {
        return !getToken().isEmpty() && getUserId() != 0;
    }

    public static synchronized void saveSession(String token, long userId) {
        prefs().edit().putString("token", token).putLong("user_id", userId).putInt("pts", 1).putLong("cursor", -1).apply();
    }

    public static synchronized void clearSession() {
        prefs().edit().clear().apply();
    }

    /** our own pts counter (kept in lockstep with what the app has applied) */
    public static synchronized int getPts() {
        return prefs().getInt("pts", 1);
    }

    public static synchronized int nextPts() {
        int v = prefs().getInt("pts", 1) + 1;
        prefs().edit().putInt("pts", v).apply();
        return v;
    }

    public static synchronized long getCursor() {
        return prefs().getLong("cursor", -1);
    }

    public static synchronized void setCursor(long c) {
        prefs().edit().putLong("cursor", c).apply();
    }

    public static synchronized long getLastMsgId() {
        return prefs().getLong("last_msg", 0);
    }

    public static synchronized void setLastMsgId(long v) {
        prefs().edit().putLong("last_msg", v).apply();
    }

    public static synchronized void setCursorIfUnset(long c) {
        if (prefs().getLong("cursor", -1) < 0) prefs().edit().putLong("cursor", c).apply();
    }

    public static JSONObject get(String file, JSONObject params, int timeoutSec) throws Exception {
        StringBuilder qs = new StringBuilder();
        if (params != null) {
            Iterator<String> it = params.keys();
            while (it.hasNext()) {
                String k = it.next();
                if (qs.length() > 0) qs.append('&');
                qs.append(URLEncoder.encode(k, "UTF-8")).append('=').append(URLEncoder.encode(String.valueOf(params.get(k)), "UTF-8"));
            }
        }
        String url = BASE_URL + file + (qs.length() > 0 ? "?" + qs : "");
        return execute(url, "GET", null, timeoutSec);
    }

    public static JSONObject post(String file, JSONObject body) throws Exception {
        return execute(BASE_URL + file, "POST", body == null ? new JSONObject() : body, 20);
    }

    private static JSONObject execute(String url, String method, JSONObject body, int timeoutSec) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod(method);
            c.setConnectTimeout(15000);
            c.setReadTimeout(timeoutSec * 1000);
            c.setRequestProperty("Accept", "application/json");
            String token = getToken();
            if (!token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
            if (body != null) {
                byte[] data = body.toString().getBytes("UTF-8");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                c.setFixedLengthStreamingMode(data.length);
                OutputStream os = c.getOutputStream();
                os.write(data);
                os.close();
            }
            int http = c.getResponseCode();
            InputStream is = http >= 400 ? c.getErrorStream() : c.getInputStream();
            StringBuilder sb = new StringBuilder();
            if (is != null) {
                BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
                r.close();
            }
            JSONObject j;
            try {
                j = new JSONObject(sb.toString());
            } catch (Exception e) {
                throw new JikException(http, "bad_response", "پاسخ نامعتبر از سرور (" + http + ")");
            }
            if (!j.optBoolean("ok", false)) {
                if (http == 401) clearSessionIfStale();
                throw new JikException(http, j.optString("error", "error"), j.optString("message", "خطا"));
            }
            return j;
        } finally {
            c.disconnect();
        }
    }

    private static void clearSessionIfStale() {
        // token رد شد؛ فقط علامت می‌ذاریم، خروج رو UI انجام می‌ده
        prefs().edit().putBoolean("expired", true).apply();
    }

    public static boolean isExpired() {
        return prefs().getBoolean("expired", false);
    }
}
