#!/usr/bin/env python3
"""JikJik rebrand: runs in CI before the build, from the repo root."""
import os, re, glob, colorsys, sys

HERE = os.path.dirname(os.path.abspath(__file__))
JAVA = 'TMessagesProj/src/main/java/org/telegram'
RES = 'TMessagesProj/src/main/res'
BRAND = 'JikJik'
stats = {}

def rd(p):
    with open(p, encoding='utf-8', errors='surrogateescape') as f:
        return f.read()
def wr(p, s):
    with open(p, 'w', encoding='utf-8', errors='surrogateescape', newline='') as f:
        f.write(s)
def bump(k, n=1):
    stats[k] = stats.get(k, 0) + n

# ---------- hue shift: blue -> green ----------
SHIFT = -0.175
def shift_rgb(r, g, b):
    h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
    if 0.52 <= h <= 0.62 and s > 0.25:
        nr, ng, nb = colorsys.hsv_to_rgb((h + SHIFT) % 1.0, s, v)
        return tuple(round(x * 255) for x in (nr, ng, nb))
    return None
def shift_hex6(h6):
    r, g, b = int(h6[0:2], 16), int(h6[2:4], 16), int(h6[4:6], 16)
    n = shift_rgb(r, g, b)
    return None if n is None else '%02x%02x%02x' % n

JAVA_COLOR = re.compile(r'0[xX]([fF][fF])([0-9a-fA-F]{6})\b')
def java_color_sub(m):
    n = shift_hex6(m.group(2))
    if n is None: return m.group(0)
    bump('java_colors')
    return '0x' + m.group(1) + n
XML_COLOR = re.compile(r'(["\'>])#([0-9a-fA-F]{2})?([0-9a-fA-F]{6})(?=["\'<])')
def xml_color_sub(m):
    n = shift_hex6(m.group(3))
    if n is None: return m.group(0)
    bump('xml_colors')
    return '%s#%s%s' % (m.group(1), m.group(2) or '', n)

# ---------- Java text ----------
LIT = [
    (re.compile(r'"Telegram"'), '"%s"' % BRAND),
    (re.compile(r'"Telegram (Images|Video|Audio|Documents|Files|Stories|Profile|Voice Call|Video Call|Beta Chat)"'), r'"%s \1"' % BRAND),
]
LINE_RULES = {
    'MessagePreviewView.java': ('Subscribe to', 'Telegram Premium', BRAND + ' Premium'),
    'NewContactBottomSheet.java': ('This phone number', 'Telegram', BRAND),
}

def process_java():
    for p in glob.glob(JAVA + '/**/*.java', recursive=True):
        s = rd(p); o = s
        for rx, rep in LIT:
            s, n = rx.subn(rep, s)
            if n: bump('java_literals', n)
        name = os.path.basename(p)
        if name in LINE_RULES:
            key, a, b = LINE_RULES[name]
            lines = s.split('\n')
            for i, l in enumerate(lines):
                if key in l and a in l:
                    lines[i] = l.replace(a, b); bump('java_lines')
            s = '\n'.join(lines)
        rel = p.replace('\\', '/')
        if '/org/telegram/ui/' in rel and name != 'ThemeColors.java':
            s = JAVA_COLOR.sub(java_color_sub, s)
        if s != o: wr(p, s)

def process_xml():
    for p in glob.glob(RES + '/**/*.xml', recursive=True):
        name = os.path.basename(p)
        if name.startswith(('strings', 'plurals', 'arrays')): continue
        s = rd(p); n = XML_COLOR.sub(xml_color_sub, s)
        if n != s: wr(p, n)

# ---------- images ----------
def process_images():
    try:
        from PIL import Image
    except ImportError:
        print('Pillow missing, skipping images'); return
    bird = Image.open(os.path.join(HERE, 'bird_white.png')).convert('RGBA')
    # raster files: same name, same pixel size
    for p in glob.glob(RES + '/drawable*/intro_tg_plane.*') + glob.glob(RES + '/drawable*/menu_invit_telegram.*'):
        try:
            w, h = Image.open(p).size
        except Exception:
            continue
        fit = min(w / bird.width, h / bird.height) * 0.92
        nb = bird.resize((max(1, int(bird.width * fit)), max(1, int(bird.height * fit))), Image.LANCZOS)
        canvas = Image.new('RGBA', (w, h), (0, 0, 0, 0))
        canvas.paste(nb, ((w - nb.width) // 2, (h - nb.height) // 2), nb)
        fmt = 'WEBP' if p.lower().endswith('.webp') else 'PNG'
        if fmt == 'WEBP': canvas.save(p, 'WEBP', lossless=True)
        else: canvas.save(p, 'PNG')
        bump('images')
    # vector logos -> wrapper around the round JikJik logo (keeps original size)
    nodpi = RES + '/drawable-nodpi'
    os.makedirs(nodpi, exist_ok=True)
    import shutil
    shutil.copy(os.path.join(HERE, 'logo_round.png'), nodpi + '/jikjik_logo_round.png')
    for name in ('telegram_logo.xml', 'telegram_logo_2.xml', 'wallet_intro_telegram.xml'):
        p = RES + '/drawable/' + name
        if not os.path.exists(p): continue
        s = rd(p)
        mw = re.search(r'android:width="([0-9.]+dp)"', s); mh = re.search(r'android:height="([0-9.]+dp)"', s)
        w = mw.group(1) if mw else '96dp'; h = mh.group(1) if mh else '96dp'
        wr(p, '<?xml version="1.0" encoding="utf-8"?>\n'
              '<layer-list xmlns:android="http://schemas.android.com/apk/res/android">\n'
              '    <item android:width="%s" android:height="%s" android:drawable="@drawable/jikjik_logo_round"/>\n'
              '</layer-list>\n' % (w, h))
        bump('xml_logos')

if __name__ == '__main__':
    process_java(); process_xml(); process_images()
    print('rebrand done:', stats)
