# نسخهٔ اصلاح‌شدهٔ پخش MKV


## وارد کردن در CodeAssist

1. ZIP را در یک پوشهٔ جدید استخراج کن.
2. پوشهٔ `JikJikAndroid` را که فایل‌های `settings.gradle` و `build.gradle` دارد باز کن.
4. سپس Build بگیر.

## وابستگی پخش



## محدودیت کدک

