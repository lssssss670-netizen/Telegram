package ir.alimsv.jikjik;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.Tracks;
import androidx.media3.common.TrackGroup;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.VideoSize;
import androidx.media3.common.text.CueGroup;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.CaptionStyleCompat;
import androidx.media3.ui.SubtitleView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Native CinemaJik player based on AndroidX Media3 (ExoPlayer): MKV/Matroska, MP4, WebM, HLS, DASH, TS...
 * External subtitles (SRT / VTT / ASS) come from the subtitle list registered in movie.json.
 */
public class NativePlayerActivity extends Activity {
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_START = "start_ms";
    public static final String EXTRA_UA = "ua";
    public static final String EXTRA_SUBS = "subs";
    public static final String EXTRA_SUBSEL = "subsel";
    public static final String RESULT_SUB = "sub";
    public static final String RESULT_POS = "pos";
    public static final String RESULT_DUR = "dur";
    public static final String RESULT_ENDED = "ended";

    private static final int ACCENT = 0xFF2ED573;
    private static final float[] SPEEDS = new float[]{1f, 1.25f, 1.5f, 2f, 0.75f};

    private final Handler h = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private SurfaceView playerView;
    private ExoPlayer player;
    private SubtitleView subView;
    private TextView subBtn;
    private final List<String[]> subs = new ArrayList<String[]>(); // {url, label, lang}
    private int selSub = -1;          // index in subs, -1 = off
    private int pendingSub = -1;      // selection waiting for its track to appear
    private boolean mediaStarted = false;
    private int vw = 0, vh = 0;
    private View controls;
    private TextView titleTv, curTv, durTv, ppBtn, speedBtn, errorTv;
    private SeekBar seek;
    private ProgressBar loading;
    private View errorBox;

    private String url;
    private String ua;
    private int startMs;
    private int lastPos = 0;
    private int lastDur = 0;
    private int speedIdx = 0;
    private boolean prepared = false;
    private boolean dragging = false;
    private boolean ended = false;
    private boolean failed = false;
    private boolean closing = false;

    private final Runnable hideRunnable = new Runnable() {
        @Override public void run() {
            if (player != null && player.isPlaying() && !failed && controls != null) {
                controls.setVisibility(View.GONE);
            }
        }
    };

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (prepared && !closing && player != null) {
                try {
                    long pos = player.getCurrentPosition();
                    long dur = player.getDuration();
                    if (pos >= 0) lastPos = (int) Math.min(Integer.MAX_VALUE, pos);
                    if (dur > 0 && dur < Integer.MAX_VALUE) lastDur = (int) dur;
                    if (!dragging && lastDur > 0) {
                        seek.setProgress((int) (lastPos * 1000L / lastDur));
                        curTv.setText(fmt(lastPos));
                    }
                } catch (Exception ignored) { }
            }
            h.postDelayed(this, 400);
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static String fmt(int ms) {
        if (ms < 0) ms = 0;
        int s = ms / 1000;
        int hh = s / 3600, mm = (s % 3600) / 60, ss = s % 60;
        if (hh > 0) return String.format(Locale.US, "%d:%02d:%02d", hh, mm, ss);
        return String.format(Locale.US, "%d:%02d", mm, ss);
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView roundBtn(String s, int sp, int fill, int fg, int sizeDp) {
        TextView t = text(s, sp, fg, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return t;
    }

    private TextView pill(String s, int fill, int fg) {
        TextView t = text(s, 14, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(18), dp(11), dp(18), dp(11));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(18));
        g.setColor(fill);
        t.setBackground(g);
        return t;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent in = getIntent();
        url = in.getStringExtra(EXTRA_URL);
        ua = in.getStringExtra(EXTRA_UA);
        startMs = Math.max(0, in.getIntExtra(EXTRA_START, 0));
        String title = in.getStringExtra(EXTRA_TITLE);
        if (url == null || url.length() == 0) { finish(); return; }
        try {
            String sj = in.getStringExtra(EXTRA_SUBS);
            if (sj != null && sj.length() > 2) {
                JSONArray arr = new JSONArray(sj);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    String su = o.optString("u", "");
                    if (su.length() == 0) continue;
                    String lb = o.optString("label", "");
                    subs.add(new String[]{su, lb.length() == 0 ? ("\u0632\u06CC\u0631\u0646\u0648\u06CC\u0633 " + (subs.size() + 1)) : lb, o.optString("lang", "")});
                }
            }
        } catch (Exception ignored) { }
        selSub = in.getIntExtra(EXTRA_SUBSEL, -1);
        if (selSub >= subs.size()) selSub = -1;
        pendingSub = selSub;

        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        playerView = new SurfaceView(this);
        playerView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override public void surfaceCreated(SurfaceHolder holder) {
                if (player == null) initializePlayer();
            }
            @Override public void surfaceChanged(SurfaceHolder holder, int f, int w, int hh) { }
            @Override public void surfaceDestroyed(SurfaceHolder holder) { }
        });
        root.addView(playerView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));

        subView = new SubtitleView(this);
        subView.setStyle(new CaptionStyleCompat(Color.WHITE, 0x99000000, Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null));
        subView.setApplyEmbeddedStyles(false);
        subView.setApplyEmbeddedFontSizes(false);
        subView.setFractionalTextSize(0.058f);
        subView.setBottomPaddingFraction(0.07f);
        subView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.addView(subView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Touch layer: single tap shows/hides controls, double tap on the sides seeks 10s.
        final View tap = new View(this);
        root.addView(tap, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (failed) return true;
                if (controls.getVisibility() == View.VISIBLE) controls.setVisibility(View.GONE);
                else showControls(false);
                return true;
            }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (failed || !prepared) return true;
                float x = e.getX() / Math.max(1f, tap.getWidth());
                if (x < 0.38f) seekBy(-10000);
                else if (x > 0.62f) seekBy(10000);
                else togglePlay();
                showControls(false);
                return true;
            }
        });
        tap.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) { return gd.onTouchEvent(e); }
        });

        FrameLayout ctl = new FrameLayout(this);
        controls = ctl;
        root.addView(ctl, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Top bar
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), dp(8), dp(16), dp(24));
        top.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xCC000000, 0x00000000}));
        TextView back = roundBtn("\u2039", 30, 0x59000000, Color.WHITE, 44);
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finishWithResult(); }
        });
        top.addView(back);
        titleTv = text(title == null ? "" : title, 15, Color.WHITE, true);
        titleTv.setSingleLine(true);
        titleTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleTv.setTextDirection(View.TEXT_DIRECTION_RTL);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tlp.leftMargin = dp(12);
        top.addView(titleTv, tlp);
        ctl.addView(top, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        // Center buttons
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.HORIZONTAL);
        mid.setGravity(Gravity.CENTER);
        TextView rew = roundBtn("\u221210", 14, 0x73000000, Color.WHITE, 56);
        ppBtn = roundBtn("\u275A\u275A", 22, ACCENT, 0xFF06140C, 74);
        TextView fwd = roundBtn("+10", 14, 0x73000000, Color.WHITE, 56);
        rew.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { seekBy(-10000); showControls(false); }
        });
        fwd.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { seekBy(10000); showControls(false); }
        });
        ppBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { togglePlay(); showControls(false); }
        });
        LinearLayout.LayoutParams m1 = new LinearLayout.LayoutParams(dp(56), dp(56));
        m1.leftMargin = dp(16); m1.rightMargin = dp(16);
        LinearLayout.LayoutParams m2 = new LinearLayout.LayoutParams(dp(74), dp(74));
        mid.addView(rew, m1);
        mid.addView(ppBtn, m2);
        mid.addView(fwd, m1);
        ctl.addView(mid, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        // Bottom seek/speed controls
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(16), dp(28), dp(16), dp(10));
        bottom.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xD9000000, 0x00000000}));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        curTv = text("0:00", 12, Color.WHITE, false);
        durTv = text("0:00", 12, Color.WHITE, false);
        seek = new SeekBar(this);
        seek.setMax(1000);
        seek.getProgressDrawable().setColorFilter(ACCENT, android.graphics.PorterDuff.Mode.SRC_IN);
        seek.getThumb().setColorFilter(ACCENT, android.graphics.PorterDuff.Mode.SRC_IN);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser && lastDur > 0) curTv.setText(fmt((int) (p * (long) lastDur / 1000)));
            }
            @Override public void onStartTrackingTouch(SeekBar s) { dragging = true; showControls(true); }
            @Override public void onStopTrackingTouch(SeekBar s) {
                if (prepared && lastDur > 0 && player != null) {
                    int to = (int) (s.getProgress() * (long) lastDur / 1000);
                    player.seekTo((long) to);
                    lastPos = to;
                }
                dragging = false;
            }
        });
        row.addView(curTv);
        row.addView(seek, new LinearLayout.LayoutParams(0, dp(32), 1f));
        row.addView(durTv);
        bottom.addView(row);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.END);
        speedBtn = pill("1x", 0x29FFFFFF, Color.WHITE);
        speedBtn.setPadding(dp(14), dp(6), dp(14), dp(6));
        speedBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                speedIdx = (speedIdx + 1) % SPEEDS.length;
                applySpeed();
                showControls(false);
            }
        });
        subBtn = pill("\u0632\u06CC\u0631\u0646\u0648\u06CC\u0633", 0x29FFFFFF, Color.WHITE);
        subBtn.setPadding(dp(14), dp(6), dp(14), dp(6));
        subBtn.setVisibility(subs.isEmpty() ? View.GONE : View.VISIBLE); // no subtitles in movie.json = no button
        subBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSubtitleDialog(); showControls(true); }
        });
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sbp.rightMargin = dp(10);
        row2.addView(subBtn, sbp);
        row2.addView(speedBtn);
        bottom.addView(row2);
        updateSubButton();
        ctl.addView(bottom, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

        loading = new ProgressBar(this);
        loading.setIndeterminate(true);
        loading.getIndeterminateDrawable().setColorFilter(ACCENT, android.graphics.PorterDuff.Mode.SRC_IN);
        root.addView(loading, new FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER));

        // Error panel with external-player fallback.
        LinearLayout eb = new LinearLayout(this);
        eb.setOrientation(LinearLayout.VERTICAL);
        eb.setGravity(Gravity.CENTER);
        eb.setBackgroundColor(0xEE000000);
        eb.setPadding(dp(30), dp(20), dp(30), dp(20));
        eb.setVisibility(View.GONE);
        errorBox = eb;
        TextView et = text("\u067E\u062E\u0634 \u0646\u0634\u062F", 20, Color.WHITE, true);
        et.setGravity(Gravity.CENTER);
        eb.addView(et);
        errorTv = text("", 14, 0xFFCFD9D3, false);
        errorTv.setGravity(Gravity.CENTER);
        errorTv.setTextDirection(View.TEXT_DIRECTION_RTL);
        errorTv.setLineSpacing(0f, 1.3f);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        elp.topMargin = dp(10); elp.bottomMargin = dp(16);
        eb.addView(errorTv, elp);
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.CENTER);
        TextView ext = pill("\u067E\u062E\u0634\u200C\u06A9\u0646\u0646\u062F\u0647\u0654 \u062F\u06CC\u06AF\u0631", ACCENT, 0xFF06140C);
        TextView bk = pill("\u0628\u0627\u0632\u06AF\u0634\u062A", 0xFF1C2F26, Color.WHITE);
        ext.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openExternal(); }
        });
        bk.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finishWithResult(); }
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.leftMargin = dp(8); blp.rightMargin = dp(8);
        btns.addView(bk, blp);
        btns.addView(ext, blp);
        eb.addView(btns);
        root.addView(eb, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);
        goImmersive();
        h.post(ticker);
    }

    private void fitVideo() {
        if (vw <= 0 || vh <= 0 || root == null || root.getWidth() <= 0) return;
        float rw = root.getWidth(), rh = root.getHeight();
        float sc = Math.min(rw / vw, rh / vh);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (vw * sc), (int) (vh * sc), Gravity.CENTER);
        playerView.setLayoutParams(lp);
    }

    private void initializePlayer() {
        try {
            DefaultRenderersFactory rf = new DefaultRenderersFactory(this)
                    .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                    .setEnableDecoderFallback(true);
            DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                    .setAllowCrossProtocolRedirects(true)
                    .setConnectTimeoutMs(15000)
                    .setReadTimeoutMs(30000);
            if (ua != null && ua.length() > 0) http.setUserAgent(ua);
            DefaultDataSource.Factory ds = new DefaultDataSource.Factory(this, http);
            player = new ExoPlayer.Builder(this, rf)
                    .setMediaSourceFactory(new DefaultMediaSourceFactory(ds))
                    .build();
            player.setVideoSurfaceView(playerView);
            // Text tracks stay off until the user picks one from the subtitle list
            player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build());
            player.addListener(new Player.Listener() {
                @Override public void onPlaybackStateChanged(int state) {
                    if (state == Player.STATE_BUFFERING) {
                        loading.setVisibility(View.VISIBLE);
                    } else {
                        loading.setVisibility(View.GONE);
                    }
                    if (state == Player.STATE_READY && !prepared) {
                        prepared = true;
                        long d = player.getDuration();
                        if (d > 0 && d < Integer.MAX_VALUE) { lastDur = (int) d; durTv.setText(fmt(lastDur)); }
                        showControls(false);
                    }
                    if (state == Player.STATE_ENDED && !ended) {
                        ended = true;
                        finishWithResult();
                    }
                    updatePlayIcon();
                }
                @Override public void onIsPlayingChanged(boolean isPlaying) {
                    updatePlayIcon();
                    if (isPlaying) showControls(false);
                }
                @Override public void onVideoSizeChanged(VideoSize size) {
                    if (size.width > 0 && size.height > 0) {
                        vw = (int) (size.width * (size.pixelWidthHeightRatio > 0 ? size.pixelWidthHeightRatio : 1f));
                        vh = size.height;
                        fitVideo();
                    }
                }
                @Override public void onCues(CueGroup cueGroup) {
                    if (subView != null) subView.setCues(cueGroup.cues);
                }
                @Override public void onTracksChanged(Tracks tracks) {
                    applyPendingSub(tracks);
                }
                @Override public void onPlayerError(PlaybackException error) {
                    showError(error.errorCode, error.getErrorCodeName());
                }
            });
            prepareMedia();
        } catch (Exception e) {
            showError(-1, e.getClass().getSimpleName());
        }
    }

    /** Downloads the registered subtitles (converted to UTF-8) in parallel, then starts playback. */
    private void prepareMedia() {
        final int n = subs.size();
        if (n == 0) { startMedia(new File[0]); return; }
        final File[] files = new File[n];
        final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(n);
        final File cache = getCacheDir();
        final String agent = ua;
        for (int i = 0; i < n; i++) {
            final int idx = i;
            final String su = subs.get(i)[0];
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        File f = SubFetcher.downloadToCache(cache, "s" + Math.abs(su.hashCode()), su, agent);
                        synchronized (files) { files[idx] = f; }
                    } catch (Exception ignored) {
                    } finally {
                        latch.countDown();
                    }
                }
            }).start();
        }
        new Thread(new Runnable() {
            @Override public void run() {
                try { latch.await(8, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
                final File[] snap = new File[n];
                synchronized (files) { System.arraycopy(files, 0, snap, 0, n); }
                runOnUiThread(new Runnable() {
                    @Override public void run() { startMedia(snap); }
                });
            }
        }).start();
    }

    private void startMedia(File[] files) {
        if (player == null || closing || mediaStarted) return;
        mediaStarted = true;
        List<MediaItem.SubtitleConfiguration> cfgs = new ArrayList<MediaItem.SubtitleConfiguration>();
        for (int i = 0; i < files.length; i++) {
            File f = files[i];
            if (f == null) continue;
            String name = f.getName().toLowerCase(Locale.US);
            String mime = name.endsWith(".vtt") ? MimeTypes.TEXT_VTT
                    : (name.endsWith(".ssa") ? MimeTypes.TEXT_SSA : MimeTypes.APPLICATION_SUBRIP);
            String[] s = subs.get(i);
            MediaItem.SubtitleConfiguration.Builder b = new MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
                    .setMimeType(mime)
                    .setLabel(s[1])
                    .setId("jjsub" + i)
                    .setSelectionFlags(0);
            if (s[2] != null && s[2].length() > 0) b.setLanguage(s[2]);
            cfgs.add(b.build());
        }
        MediaItem item = new MediaItem.Builder()
                .setUri(Uri.parse(url))
                .setSubtitleConfigurations(cfgs)
                .build();
        player.setMediaItem(item);
        if (startMs > 0) player.seekTo(startMs);
        player.prepare();
        player.setPlayWhenReady(true);
        if (speedIdx != 0) applySpeed();
    }

    private TrackGroup findSubGroup(Tracks tracks, int idx) {
        List<Tracks.Group> text = new ArrayList<Tracks.Group>();
        for (Tracks.Group g : tracks.getGroups()) if (g.getType() == C.TRACK_TYPE_TEXT && g.length > 0) text.add(g);
        String wantId = "jjsub" + idx;
        for (Tracks.Group g : text) {
            Format f = g.getTrackFormat(0);
            if (f.id != null && (f.id.equals(wantId) || f.id.endsWith(":" + wantId))) return g.getMediaTrackGroup();
        }
        String wantLabel = subs.get(idx)[1];
        for (Tracks.Group g : text) {
            Format f = g.getTrackFormat(0);
            if (f.label != null && f.label.equals(wantLabel)) return g.getMediaTrackGroup();
        }
        return null;
    }

    private void applyPendingSub(Tracks tracks) {
        if (pendingSub < 0 || pendingSub >= subs.size() || player == null) return;
        TrackGroup g = findSubGroup(tracks, pendingSub);
        if (g == null) return;
        pendingSub = -1;
        selectSubGroup(g);
    }

    private void selectSubGroup(TrackGroup g) {
        if (player == null) return;
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
        if (g == null) {
            b.clearOverridesOfType(C.TRACK_TYPE_TEXT).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true);
            if (subView != null) subView.setCues(new ArrayList<androidx.media3.common.text.Cue>());
        } else {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).setOverrideForType(new TrackSelectionOverride(g, 0));
        }
        player.setTrackSelectionParameters(b.build());
    }

    private void chooseSub(int idx) {
        selSub = idx;
        pendingSub = -1;
        updateSubButton();
        if (idx < 0) { selectSubGroup(null); return; }
        TrackGroup g = player == null ? null : findSubGroup(player.getCurrentTracks(), idx);
        if (g == null) {
            Toast.makeText(this, "\u0632\u06CC\u0631\u0646\u0648\u06CC\u0633 \u0628\u0627\u0632 \u0646\u0634\u062F", Toast.LENGTH_SHORT).show();
            selSub = -1;
            updateSubButton();
            return;
        }
        selectSubGroup(g);
    }

    private void updateSubButton() {
        if (subBtn == null) return;
        subBtn.setText(selSub >= 0 && selSub < subs.size() ? subs.get(selSub)[1] : "\u0632\u06CC\u0631\u0646\u0648\u06CC\u0633");
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(18));
        g.setColor(selSub >= 0 ? ACCENT : 0x29FFFFFF);
        subBtn.setBackground(g);
        subBtn.setTextColor(selSub >= 0 ? 0xFF06140C : Color.WHITE);
    }

    private void showSubtitleDialog() {
        if (subs.isEmpty()) return;
        String[] names = new String[subs.size() + 1];
        names[0] = "\u062E\u0627\u0645\u0648\u0634";
        for (int i = 0; i < subs.size(); i++) names[i + 1] = subs.get(i)[1];
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("\u0632\u06CC\u0631\u0646\u0648\u06CC\u0633")
                .setSingleChoiceItems(names, selSub + 1, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        chooseSub(which - 1);
                    }
                })
                .create();
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface dialog) { goImmersive(); }
        });
        d.show();
    }

    private void goImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
    }

    private void showControls(boolean keep) {
        if (controls == null) return;
        controls.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideRunnable);
        if (!keep && prepared && player != null && player.isPlaying()) {
            h.postDelayed(hideRunnable, 3200);
        }
    }

    private void togglePlay() {
        if (player == null) return;
        try { if (player.getPlayWhenReady()) player.pause(); else player.play(); } catch (Exception ignored) { }
        updatePlayIcon();
    }

    private void updatePlayIcon() {
        if (ppBtn == null || player == null) return;
        ppBtn.setText(player.getPlayWhenReady() && player.getPlaybackState() != Player.STATE_ENDED ? "\u275A\u275A" : "\u25B6\uFE0E");
    }

    private void seekBy(int deltaMs) {
        if (!prepared || player == null) return;
        long duration = player.getDuration();
        long to = player.getCurrentPosition() + deltaMs;
        if (to < 0) to = 0;
        if (duration > 0 && to > duration - 500) to = Math.max(0, duration - 500);
        player.seekTo(to);
        lastPos = (int) Math.min(Integer.MAX_VALUE, to);
    }

    private void applySpeed() {
        float sp = SPEEDS[speedIdx];
        speedBtn.setText(sp == (int) sp ? ((int) sp) + "x" : sp + "x");
        if (player != null) {
            try { player.setPlaybackSpeed(sp); } catch (Exception ignored) { }
        }
    }

    private void showError(int code, String detail) {
        failed = true;
        if (loading != null) loading.setVisibility(View.GONE);
        if (controls != null) controls.setVisibility(View.GONE);
        if (errorTv != null) {
            String reason = "\u067E\u0644\u06CC\u0631 \u0646\u062A\u0648\u0627\u0646\u0633\u062A \u0641\u0627\u06CC\u0644 \u0631\u0627 \u067E\u062E\u0634 \u06A9\u0646\u062F.\n"
                    + "\u0641\u0631\u0645\u062A MKV \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0645\u06CC\u200C\u0634\u0648\u062F\u060C \u0627\u0645\u0627 \u06A9\u062F\u06A9 \u062A\u0635\u0648\u06CC\u0631/\u0635\u062F\u0627\u06CC \u062F\u0627\u062E\u0644 \u0641\u0627\u06CC\u0644 \u0647\u0645 \u0628\u0627\u06CC\u062F \u062A\u0648\u0633\u0637 \u062F\u0633\u062A\u06AF\u0627\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0634\u0648\u062F.\n"
                    + "\u0627\u062A\u0635\u0627\u0644 \u06CC\u0627 \u0644\u06CC\u0646\u06A9 \u0641\u0627\u06CC\u0644 \u0646\u06CC\u0632 \u0645\u0645\u06A9\u0646 \u0627\u0633\u062A \u0645\u0634\u06A9\u0644 \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F.\n"
                    + "(" + code + (detail == null ? "" : " / " + detail) + ")";
            errorTv.setText(reason);
        }
        if (errorBox != null) errorBox.setVisibility(View.VISIBLE);
    }

    private void openExternal() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(url), "video/*");
            startActivity(Intent.createChooser(i, null));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception e2) {
                Toast.makeText(this, "\u0628\u0631\u0646\u0627\u0645\u0647\u200C\u0627\u06CC \u0628\u0631\u0627\u06CC \u067E\u062E\u0634 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        finishWithResult();
    }

    private void finishWithResult() {
        if (closing) return;
        closing = true;
        h.removeCallbacks(hideRunnable);
        int pos = lastPos, dur = lastDur;
        try {
            if (player != null && prepared && !ended) {
                long p = player.getCurrentPosition();
                if (p > 0) pos = (int) Math.min(Integer.MAX_VALUE, p);
                long d = player.getDuration();
                if (d > 0 && d < Integer.MAX_VALUE) dur = (int) d;
            }
        } catch (Exception ignored) { }
        if (ended && dur > 0) pos = dur;
        Intent r = new Intent();
        r.putExtra(RESULT_POS, pos / 1000.0);
        r.putExtra(RESULT_DUR, dur / 1000.0);
        r.putExtra(RESULT_ENDED, ended);
        r.putExtra(RESULT_SUB, selSub >= 0 && selSub < subs.size() ? subs.get(selSub)[1] : "");
        setResult(RESULT_OK, r);
        finish();
    }

    @Override
    public void onBackPressed() {
        finishWithResult();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (player != null && prepared && !closing) {
                lastPos = (int) Math.min(Integer.MAX_VALUE, player.getCurrentPosition());
                player.pause();
                updatePlayIcon();
                controls.setVisibility(View.VISIBLE);
            }
        } catch (Exception ignored) { }
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        try {
            if (player != null) {
                player.release();
                player = null;
            }
        } catch (Exception ignored) { }
        super.onDestroy();
    }
}
