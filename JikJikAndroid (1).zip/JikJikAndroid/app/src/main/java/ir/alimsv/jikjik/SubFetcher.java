package ir.alimsv.jikjik;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;

/** Downloads a subtitle file and always returns clean UTF-8 text (many Persian .srt files are Windows-1256). */
final class SubFetcher {
    private static final int MAX_BYTES = 4 * 1024 * 1024;

    private SubFetcher() { }

    static byte[] download(String url, String ua) throws IOException {
        String target = url;
        for (int hop = 0; hop < 6; hop++) {
            URL u = new URL(target);
            String sc = u.getProtocol().toLowerCase();
            if (!"http".equals(sc) && !"https".equals(sc)) throw new IOException("bad scheme");
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            try {
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                c.setRequestProperty("Accept", "*/*");
                c.setRequestProperty("User-Agent", ua != null && ua.length() > 0 ? ua
                        : "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null) throw new IOException("redirect without location");
                    target = new URL(u, loc).toString();
                    continue;
                }
                if (code < 200 || code >= 300) throw new IOException("HTTP " + code);
                return readLimited(c.getInputStream());
            } finally {
                c.disconnect();
            }
        }
        throw new IOException("too many redirects");
    }

    private static byte[] readLimited(InputStream in) throws IOException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                if (out.size() > MAX_BYTES) throw new IOException("too large");
            }
            return out.toByteArray();
        } finally {
            try { in.close(); } catch (IOException ignored) { }
        }
    }

    /** UTF-8 (with/without BOM), UTF-16 (BOM) or Windows-1256 / Latin-1 fallback. */
    static String decode(byte[] raw) {
        if (raw.length >= 3 && (raw[0] & 0xFF) == 0xEF && (raw[1] & 0xFF) == 0xBB && (raw[2] & 0xFF) == 0xBF) {
            return new String(raw, 3, raw.length - 3, StandardCharsets.UTF_8);
        }
        if (raw.length >= 2 && (raw[0] & 0xFF) == 0xFF && (raw[1] & 0xFF) == 0xFE) {
            return new String(raw, 2, raw.length - 2, StandardCharsets.UTF_16LE);
        }
        if (raw.length >= 2 && (raw[0] & 0xFF) == 0xFE && (raw[1] & 0xFF) == 0xFF) {
            return new String(raw, 2, raw.length - 2, StandardCharsets.UTF_16BE);
        }
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(raw)).toString();
        } catch (CharacterCodingException e) {
            try {
                return new String(raw, Charset.forName("windows-1256"));
            } catch (Exception e2) {
                return new String(raw, StandardCharsets.ISO_8859_1);
            }
        }
    }

    /** "vtt", "ssa" or "srt" (decided by content first, then by extension). */
    static String kindOf(String text, String url) {
        String head = text.length() > 400 ? text.substring(0, 400) : text;
        String h = head.trim();
        if (h.startsWith("WEBVTT")) return "vtt";
        if (text.contains("[Script Info]") || text.contains("\nDialogue:") || h.startsWith("Dialogue:")) return "ssa";
        String p = url.toLowerCase();
        int q = p.indexOf('?');
        if (q >= 0) p = p.substring(0, q);
        if (p.endsWith(".vtt")) return "vtt";
        if (p.endsWith(".ass") || p.endsWith(".ssa")) return "ssa";
        return "srt";
    }

    /** Downloads, converts to UTF-8 and stores as cacheDir/subs/<name>.<kind>. Returns the file. */
    static File downloadToCache(File cacheDir, String name, String url, String ua) throws IOException {
        String text = decode(download(url, ua));
        String kind = kindOf(text, url);
        File dir = new File(cacheDir, "subs");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("cache dir");
        File f = new File(dir, name + "." + kind);
        FileOutputStream fo = new FileOutputStream(f);
        try {
            fo.write(text.getBytes(StandardCharsets.UTF_8));
        } finally {
            fo.close();
        }
        return f;
    }
}
